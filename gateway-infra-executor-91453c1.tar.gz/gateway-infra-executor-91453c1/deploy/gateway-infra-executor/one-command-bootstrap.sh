#!/usr/bin/env bash
set -Eeuo pipefail
export GIT_TERMINAL_PROMPT=0

# Intended to be pasted as the single human command's payload on the gateway.
# It obtains only the sanitized immutable public artifact, verifies its digest,
# extracts the package, and invokes the package installer. Private source and
# credentials are never requested by this bootstrap.
EXPECTED_COMMIT="d287159"
PUBLIC_ARTIFACT_URL="https://raw.githubusercontent.com/rede-industrial/frota-bootstrap/5f0f758641d78722dba4d789e14424156616d156/gateway-infra-executor-d287159.tar.gz"
EXPECTED_SHA256="2cb23ea53d0f9f5f86b0c74ffcc26f9ae1fd85fd535b817fdae84c392f7a21a9"
ROOT="/var/tmp/frota-core-gateway-bootstrap-${EXPECTED_COMMIT}"
EXPECTED_GATEWAY_IP="192.168.2.193"
[[ "$(id -u)" == "0" ]] || { echo 'run through sudo as a human administrator' >&2; exit 1; }
ip -4 -o addr show | awk '{print $4}' | cut -d/ -f1 | grep -Fxq "${EXPECTED_GATEWAY_IP}" || { echo 'wrong gateway host' >&2; exit 1; }
rm -rf -- "${ROOT}"
mkdir -p "${ROOT}"
ARCHIVE="${ROOT}/bootstrap.tar.gz"
curl --fail --silent --show-error --location --proto '=https' --tlsv1.2 --max-time 30 "${PUBLIC_ARTIFACT_URL}" -o "${ARCHIVE}" || { echo 'public bootstrap download failed' >&2; exit 1; }
[[ "$(sha256sum "${ARCHIVE}" | cut -d' ' -f1)" == "${EXPECTED_SHA256}" ]] || { echo 'public bootstrap hash mismatch' >&2; exit 1; }
tar -xzf "${ARCHIVE}" -C "${ROOT}" --strip-components=1
[[ -f "${ROOT}/deploy/gateway-infra-executor/install.sh" ]] || { echo 'package extraction failed' >&2; exit 1; }
exec bash "${ROOT}/deploy/gateway-infra-executor/install.sh"
