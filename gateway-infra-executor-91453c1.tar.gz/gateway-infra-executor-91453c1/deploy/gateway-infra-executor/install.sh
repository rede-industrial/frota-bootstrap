#!/usr/bin/env bash
set -Eeuo pipefail
[[ "$(id -u)" == "0" ]] || { echo 'run through sudo as a human administrator' >&2; exit 1; }
ROOT="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/../.." && pwd)"; DEST=/opt/frota/gateway-infra-executor; CONFIG_DIR=/etc/frota/gateway-infra-executor; CONFIG=${CONFIG_DIR}/config.json; CRED=${CONFIG_DIR}/core-credential
[[ -f "${ROOT}/gateway_infra_executor/executor.py" ]] || { echo 'canonical package missing' >&2; exit 1; }
install -d -o root -g root -m 0755 "${CONFIG_DIR}"
if [[ ! -f "${CONFIG}" ]]; then
  [[ -f "${ROOT}/gateway_infra_executor/config.example.json" ]] || { echo 'config example missing' >&2; exit 1; }
  install -o root -g root -m 0600 "${ROOT}/gateway_infra_executor/config.example.json" "${CONFIG}"
fi
[[ -f "${CRED}" ]] || { echo 'pre-provisioned CORE credential missing; no secret generated' >&2; exit 1; }
id frota-deployer >/dev/null 2>&1 || { echo 'frota-deployer account missing' >&2; exit 1; }
[[ -f /home/sigma/.ssh/frota-truck-ed25519 && -f /home/sigma/.ssh/known_hosts ]] || { echo 'gateway SSH channel references missing' >&2; exit 1; }
[[ "$(stat -c '%U:%a' "${CONFIG}")" == 'root:600' && "$(stat -c '%a' "${CRED}")" == '600' ]] || { echo 'config or credential permissions invalid' >&2; exit 1; }
curl --fail --silent --show-error --max-time 10 http://192.168.2.186:8080/health >/dev/null || { echo 'FROTA-CORE health unavailable' >&2; exit 1; }
python3 "${ROOT}/gateway_infra_executor/executor.py" --config "${CONFIG}" --check-only >/dev/null || { echo 'FROTA-CORE messages inbox unavailable' >&2; exit 1; }
ssh -i /home/sigma/.ssh/frota-truck-ed25519 -o BatchMode=yes -o StrictHostKeyChecking=yes -o UserKnownHostsFile=/home/sigma/.ssh/known_hosts frota-deployer@192.168.2.186 true >/dev/null || { echo 'TRUCK admin channel unavailable' >&2; exit 1; }
install -d -o root -g root -m 0755 "${DEST}" /var/lib/frota-gateway-infra-executor
install -o root -g root -m 0755 "${ROOT}/gateway_infra_executor/executor.py" "${DEST}/executor.py"; install -o root -g root -m 0644 "${ROOT}/gateway_infra_executor/__init__.py" "${DEST}/__init__.py"; install -o root -g root -m 0644 "${ROOT}/deploy/gateway-infra-executor/frota-gateway-infra-executor.service" /etc/systemd/system/frota-gateway-infra-executor.service
chown -R frota-deployer:frota-deployer /var/lib/frota-gateway-infra-executor; systemctl daemon-reload; systemctl enable --now frota-gateway-infra-executor.service; systemctl is-enabled --quiet frota-gateway-infra-executor.service; systemctl is-active --quiet frota-gateway-infra-executor.service
printf '%s\n' '{"status":"completed","canonical_commit":"d78d6bd","resume_chain":[162,161,159,157,155]}' > /var/lib/frota-gateway-infra-executor/bootstrap-state.json
chown frota-deployer:frota-deployer /var/lib/frota-gateway-infra-executor/bootstrap-state.json; chmod 0640 /var/lib/frota-gateway-infra-executor/bootstrap-state.json
