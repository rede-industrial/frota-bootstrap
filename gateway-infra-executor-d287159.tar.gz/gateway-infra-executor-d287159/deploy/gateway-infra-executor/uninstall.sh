#!/usr/bin/env bash
set -Eeuo pipefail
[[ "$(id -u)" == "0" ]] || { echo 'run through sudo as a human administrator' >&2; exit 1; }
systemctl disable --now frota-gateway-infra-executor.service 2>/dev/null || true; rm -f /etc/systemd/system/frota-gateway-infra-executor.service; rm -rf /opt/frota/gateway-infra-executor /var/lib/frota-gateway-infra-executor; systemctl daemon-reload; echo 'GATEWAY_INFRA_EXECUTOR_ROLLED_BACK=TRUE'
