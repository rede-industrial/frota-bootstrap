#!/usr/bin/env bash
set -Eeuo pipefail
[[ "$(id -u)" == "0" ]] || { echo 'run through sudo as a human administrator' >&2; exit 1; }
ROOT="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/../.." && pwd)"; DEST=/opt/frota/gateway-infra-executor; CONFIG_DIR=/etc/frota/gateway-infra-executor; CONFIG=${CONFIG_DIR}/config.json; CRED=${CONFIG_DIR}/core-credential
[[ -f "${ROOT}/gateway_infra_executor/executor.py" && -f "${CONFIG}" && -f "${CRED}" ]] || { echo 'canonical package/config/credential missing; no secret generated' >&2; exit 1; }
[[ "$(stat -c '%U:%a' "${CONFIG}")" == 'root:600' && "$(stat -c '%a' "${CRED}")" == '600' ]] || { echo 'config or credential permissions invalid' >&2; exit 1; }
install -d -o root -g root -m 0755 "${DEST}" /var/lib/frota-gateway-infra-executor
install -o root -g root -m 0755 "${ROOT}/gateway_infra_executor/executor.py" "${DEST}/executor.py"; install -o root -g root -m 0644 "${ROOT}/gateway_infra_executor/__init__.py" "${DEST}/__init__.py"; install -o root -g root -m 0644 "${ROOT}/deploy/gateway-infra-executor/frota-gateway-infra-executor.service" /etc/systemd/system/frota-gateway-infra-executor.service
chown -R frota-deployer:frota-deployer /var/lib/frota-gateway-infra-executor; systemctl daemon-reload; systemctl enable --now frota-gateway-infra-executor.service
