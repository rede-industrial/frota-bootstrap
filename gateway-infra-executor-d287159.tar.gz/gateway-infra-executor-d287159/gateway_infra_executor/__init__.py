"""Gateway-only infrastructure executor."""
