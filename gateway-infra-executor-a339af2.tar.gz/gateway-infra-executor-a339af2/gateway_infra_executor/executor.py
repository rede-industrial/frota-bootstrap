from __future__ import annotations
import argparse, hashlib, json, os, shlex, subprocess, tempfile, time, urllib.parse, urllib.request, uuid
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Callable

ALLOWED_OPERATIONS = frozenset({"COPY_APPROVED_ARTIFACT", "CONTROL_PLANE_MIGRATION", "DEPLOY_APPROVED_COMMIT", "RESTART_APPROVED_SERVICE", "HEALTH_CHECK", "READ_LOG", "ROLLBACK_APPROVED_DEPLOY"})
ENABLED_OPERATIONS = frozenset({"COPY_APPROVED_ARTIFACT"})
CANONICAL_COMMIT = "4069f2e"
CANONICAL_ARTIFACT = "deploy/command-160/bootstrap-frota-admin.sh"
TARGET_HOST, TARGET_USER, TARGET_PATH = "192.168.2.186", "frota-deployer", "/home/frota-deployer/bootstrap-frota-admin.sh"

class ExecutorError(RuntimeError): pass

@dataclass(frozen=True)
class ExecutorConfig:
    core_url: str; agent: str; agent_id: int; capability: str; credential_file: Path; ssh_key: Path; known_hosts: Path; canonical_repo: Path
    target_host: str = TARGET_HOST; target_user: str = TARGET_USER; target_path: str = TARGET_PATH
    state_file: Path = Path("/var/lib/frota-gateway-infra-executor/state.json")

    @classmethod
    def load(cls, path: Path) -> "ExecutorConfig":
        data = json.loads(path.read_text(encoding="utf-8"))
        required = ("core_url", "agent", "agent_id", "capability", "credential_file", "ssh_key", "known_hosts", "canonical_repo")
        missing = [key for key in required if not data.get(key)]
        if missing: raise ExecutorError("CONFIG_REQUIRED:" + ",".join(missing))
        if str(data["capability"]).upper() != "INFRA_DEVOPS": raise ExecutorError("CAPABILITY_MUST_BE_INFRA_DEVOPS")
        return cls(str(data["core_url"]).rstrip("/"), str(data["agent"]), int(data["agent_id"]), "INFRA_DEVOPS", Path(data["credential_file"]), Path(data["ssh_key"]), Path(data["known_hosts"]), Path(data["canonical_repo"]), str(data.get("target_host", TARGET_HOST)), str(data.get("target_user", TARGET_USER)), str(data.get("target_path", TARGET_PATH)), Path(data.get("state_file", cls.state_file)))

def artifact_sha256(content: bytes) -> str: return hashlib.sha256(content).hexdigest()

def validate_copy_job(metadata: dict[str, Any], config: ExecutorConfig) -> None:
    if config.capability != "INFRA_DEVOPS": raise ExecutorError("CAPABILITY_NOT_AUTHORIZED")
    if str(metadata.get("operation", "")).upper() not in ALLOWED_OPERATIONS: raise ExecutorError("UNKNOWN_TYPED_OPERATION")
    if str(metadata.get("operation", "")).upper() not in ENABLED_OPERATIONS: raise ExecutorError("OPERATION_NOT_ENABLED")
    if str(metadata.get("commit")) != CANONICAL_COMMIT: raise ExecutorError("COMMIT_NOT_APPROVED")
    if str(metadata.get("artifact")) != CANONICAL_ARTIFACT: raise ExecutorError("ARTIFACT_NOT_APPROVED")
    if (config.target_host, config.target_user, config.target_path) != (TARGET_HOST, TARGET_USER, TARGET_PATH): raise ExecutorError("TARGET_NOT_ALLOWLISTED")

def _safe_note(value: str) -> str: return " ".join(value.replace("\n", " ").replace("\r", " ").split())[:1000]

class CoreClient:
    def __init__(self, config: ExecutorConfig, opener: Callable[..., Any] | None = None):
        self.config, self.opener = config, opener or urllib.request.urlopen
        self.key = config.credential_file.read_text(encoding="utf-8").strip()
        if not self.key: raise ExecutorError("CORE_CREDENTIAL_EMPTY")
    def request(self, method: str, path: str, body: dict[str, Any] | None = None) -> dict[str, Any]:
        request = urllib.request.Request(self.config.core_url + path, data=json.dumps(body).encode() if body is not None else None, method=method, headers={"Accept":"application/json", "Content-Type":"application/json", "X-Frota-Agent":self.config.agent, "X-Frota-Key":self.key})
        try:
            with self.opener(request, timeout=15) as response: payload = json.loads(response.read().decode("utf-8"))
        except Exception as exc: raise ExecutorError(f"CORE_REQUEST_FAILED:{method}:{path}") from exc
        if not isinstance(payload, dict): raise ExecutorError("CORE_RESPONSE_INVALID")
        return payload
    def inbox(self, cursor: int = 0) -> dict[str, Any]: return self.request("GET", "/messages/inbox?" + urllib.parse.urlencode({"after_id":cursor,"limit":50}))
    def claim(self, handoff_id: str, claim_id: str) -> dict[str, Any]: return self.request("POST", f"/messages/handoffs/{urllib.parse.quote(handoff_id, safe='')}/claim", {"claim_id":claim_id})
    def event(self, event_type: str, payload: dict[str, Any]) -> dict[str, Any]: return self.request("POST", "/events", {"event_type":event_type,"agent_id":self.config.agent_id,"payload":payload})
    def ack(self, message_id: int, status: str, note: str) -> dict[str, Any]: return self.request("POST", f"/messages/{message_id}/ack", {"status":status,"note":_safe_note(note)})

class GatewayExecutor:
    def __init__(self, config: ExecutorConfig, client: CoreClient | None = None, runner: Callable[..., subprocess.CompletedProcess] | None = None): self.config, self.client, self.runner = config, client, runner or subprocess.run
    def _state(self): return json.loads(self.config.state_file.read_text()) if self.config.state_file.exists() else {"cursor":0,"completed_jobs":[]}
    def _save(self, state):
        self.config.state_file.parent.mkdir(parents=True, exist_ok=True); temp=self.config.state_file.with_suffix(".tmp"); temp.write_text(json.dumps(state, sort_keys=True)); os.replace(temp, self.config.state_file)
    def _ssh_args(self): return ["-i",str(self.config.ssh_key),"-o","BatchMode=yes","-o","StrictHostKeyChecking=yes","-o",f"UserKnownHostsFile={self.config.known_hosts}"]
    def copy_approved_artifact(self, metadata):
        validate_copy_job(metadata, self.config); source=subprocess.check_output(["git","-C",str(self.config.canonical_repo),"show",f"{CANONICAL_COMMIT}:{CANONICAL_ARTIFACT}"]); digest=artifact_sha256(source); remote_tmp=self.config.target_path+".tmp"
        with tempfile.NamedTemporaryFile(prefix="frota-bootstrap-", delete=False) as handle: handle.write(source); local=Path(handle.name)
        try:
            copied=self.runner(["scp",*self._ssh_args(),str(local),f"{self.config.target_user}@{self.config.target_host}:{remote_tmp}"],check=False,capture_output=True,text=True)
            if copied.returncode: raise ExecutorError("SSH_COPY_FAILED")
            remote="set -eu; sha256sum -- {tmp}; install -o frota-deployer -g frota-deployer -m 0755 -- {tmp} {dst}; sha256sum -- {dst}; bash -n -- {dst}".format(tmp=shlex.quote(remote_tmp),dst=shlex.quote(self.config.target_path))
            checked=self.runner(["ssh",*self._ssh_args(),f"{self.config.target_user}@{self.config.target_host}",remote],check=False,capture_output=True,text=True)
            if checked.returncode or digest not in (checked.stdout or ""): raise ExecutorError("REMOTE_HASH_OR_SYNTAX_MISMATCH")
        finally: local.unlink(missing_ok=True)
        return {"operation":"COPY_APPROVED_ARTIFACT","artifact":CANONICAL_ARTIFACT,"commit":CANONICAL_COMMIT,"artifact_hash":digest,"target":self.config.target_path,"target_host":self.config.target_host}
    def process_message(self, message):
        metadata=message.get("metadata") or {}
        if str(metadata.get("kind","")).upper()!="HANDOFF" or str(metadata.get("required_capability","")).upper()!=self.config.capability: return {"status":"IGNORED"}
        if metadata.get("target_agent") and str(metadata["target_agent"]).casefold()!=self.config.agent.casefold(): return {"status":"IGNORED"}
        handoff_id=str(metadata.get("handoff_id") or ""); state=self._state()
        if not handoff_id: raise ExecutorError("HANDOFF_ID_REQUIRED")
        if handoff_id in state.get("completed_jobs",[]): return {"status":"DUPLICATE_REJECTED","handoff_id":handoff_id}
        if self.client is None: self.client=CoreClient(self.config)
        claim_id="gw-"+uuid.uuid4().hex; self.client.claim(handoff_id,claim_id); started=time.monotonic(); self.client.event("gateway_job_started", {"handoff_id":handoff_id,"operation":metadata.get("operation"),"executor":"GATEWAY_INFRA_EXECUTOR"})
        try:
            result=self.copy_approved_artifact(metadata); result.update({"handoff_id":handoff_id,"duration_ms":int((time.monotonic()-started)*1000)}); self.client.event("gateway_job_completed",result); self.client.ack(int(message["id"]),"processed","typed infrastructure job completed"); state.setdefault("completed_jobs",[]).append(handoff_id); state["cursor"]=max(int(state.get("cursor",0)),int(message["id"])); self._save(state); return {"status":"COMPLETED",**result}
        except Exception as exc:
            note=_safe_note(str(exc)); self.client.event("gateway_job_failed",{"handoff_id":handoff_id,"operation":metadata.get("operation"),"reason":note}); self.client.ack(int(message["id"]),"rejected",note); return {"status":"FAILED","handoff_id":handoff_id,"reason":note}
    def run_once(self):
        if self.client is None: self.client=CoreClient(self.config)
        state=self._state(); results=[]
        for message in self.client.inbox(int(state.get("cursor",0))).get("messages",[]): results.append(self.process_message(message))
        return results

def main():
    parser=argparse.ArgumentParser(); parser.add_argument("--config",type=Path,required=True); parser.add_argument("--once",action="store_true"); parser.add_argument("--check-only",action="store_true"); args=parser.parse_args(); executor=GatewayExecutor(ExecutorConfig.load(args.config))
    if args.check_only: executor.client=CoreClient(executor.config); executor.client.inbox(0); return 0
    if args.once: executor.run_once(); return 0
    while True: executor.run_once(); time.sleep(30)

if __name__ == "__main__": raise SystemExit(main())
